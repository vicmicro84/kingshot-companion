package com.kingshot.companion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF171321)
private val Panel = Color(0xFF292238)
private val Violet = Color(0xFFB99AFB)
private val Gold = Color(0xFFFFD58A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("player_profile", MODE_PRIVATE)
        setContent {
            var tab by remember { mutableStateOf("Home") }
            var playerId by remember { mutableStateOf(prefs.getString("playerId", "") ?: "") }
            var kingdom by remember { mutableStateOf(prefs.getString("kingdom", "") ?: "") }
            var power by remember { mutableStateOf(prefs.getString("power", "") ?: "") }
            var heroes by remember { mutableStateOf(prefs.getString("heroes", "") ?: "") }
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Gold, background = Ink, surface = Panel)) {
                Scaffold(containerColor = Ink, bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        listOf("Home", "Heroes", "Calculators", "Profile").forEach { item ->
                            NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {
                                Icon(when(item) { "Home" -> Icons.Default.Home; "Heroes" -> Icons.Default.Shield; "Calculators" -> Icons.Default.Calculate; else -> Icons.Default.Person }, null)
                            }, label = { Text(item) })
                        }
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                        Text("KING SHOT", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("Ultimate Companion", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        when(tab) {
                            "Home" -> HomeScreen(playerId, kingdom, power, heroes)
                            "Heroes" -> HeroesScreen(heroes) { heroes = it; prefs.edit().putString("heroes", it).apply() }
                            "Calculators" -> CalculatorScreen()
                            else -> ProfileScreen(playerId, { playerId = it; prefs.edit().putString("playerId", it).apply() }, kingdom, { kingdom = it; prefs.edit().putString("kingdom", it).apply() }, power, { power = it; prefs.edit().putString("power", it).apply() })
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun Tile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp))
            Column { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = Color.LightGray, fontSize = 12.sp) }
        }
    }
}

@Composable private fun HomeScreen(playerId: String, kingdom: String, power: String, heroes: String) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) {
            Text("YOUR KINGDOM", color = Gold, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
            Text(if (playerId.isBlank()) "Add your player details in Profile" else "Player ID: $playerId", color = Color.White)
            Text("Kingdom: ${kingdom.ifBlank { "Not entered" }}", color = Color.LightGray)
            Text("Power: ${power.ifBlank { "Not entered" }}", color = Color.LightGray)
        } } }
        item { Tile("Hero workshop", "Track heroes and plan upgrades", Icons.Default.Shield) }
        item { Tile("Battle lab", "Compare lineups and troop ratios", Icons.Default.SportsMma) }
        item { Tile("Resource planner", "Estimate costs and upgrade priorities", Icons.Default.Inventory) }
        item { Tile("Game modes", "Conquest, Arena, Bear Trap and more", Icons.Default.EmojiEvents) }
        item { Text("Sync status: Manual profile", color = Gold, fontWeight = FontWeight.SemiBold) }
        item { Text("Automatic game synchronisation is not connected yet. This version stores your entered profile on this device.", color = Color.LightGray, fontSize = 12.sp) }
    }
}

@Composable private fun ProfileScreen(playerId: String, onId: (String)->Unit, kingdom: String, onKingdom: (String)->Unit, power: String, onPower: (String)->Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Player profile", color = Gold, fontWeight = FontWeight.Bold) }
        item { Field("King Shot Player ID", playerId, onId) }
        item { Field("Kingdom number", kingdom, onKingdom) }
        item { Field("Total power", power, onPower, KeyboardType.Number) }
        item { Text("Google-linked account selected. Google sign-in is not enabled in this build: it requires a registered OAuth client and a supported game-data authorisation method. Never enter your Google password here.", color = Color.LightGray, fontSize = 13.sp) }
        item { Text("Your profile entries are saved locally on this phone.", color = Violet, fontSize = 12.sp) }
    }
}

@Composable private fun HeroesScreen(heroes: String, onHeroes: (String)->Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Hero roster", color = Gold, fontWeight = FontWeight.Bold)
        Text("Enter one hero per line. Include power, stars or skills if known.", color = Color.LightGray, fontSize = 13.sp)
        OutlinedTextField(value = heroes, onValueChange = onHeroes, modifier = Modifier.fillMaxWidth().height(230.dp), label = { Text("Example: Zoe — 1.5M power — 5 stars") }, minLines = 7)
        Text("Saved automatically on this device.", color = Violet, fontSize = 12.sp)
    }
}

@Composable private fun CalculatorScreen() {
    var troops by remember { mutableStateOf("100000") }
    var minutes by remember { mutableStateOf("60") }
    var base by remember { mutableStateOf("1000000") }
    var bonus by remember { mutableStateOf("0") }
    val troopCount = troops.toLongOrNull() ?: 0L
    val duration = minutes.toDoubleOrNull() ?: 0.0
    val baseDamage = base.toDoubleOrNull() ?: 0.0
    val bonusPct = bonus.toDoubleOrNull() ?: 0.0
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Quick calculators", color = Gold, fontWeight = FontWeight.Bold) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Troop training time", color = Color.White, fontWeight = FontWeight.Bold)
            Field("Number of troops", troops, { troops = it }, KeyboardType.Number)
            Field("Minutes per troop (estimate)", minutes, { minutes = it }, KeyboardType.Decimal)
            Text("Estimated total: ${"%.1f".format(troopCount * duration / 60.0)} hours", color = Gold)
            Text("This is a simple estimate; bonuses, queues and game-specific training rules are not included.", color = Color.LightGray, fontSize = 11.sp)
        } } }
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Bear Trap / damage estimate", color = Color.White, fontWeight = FontWeight.Bold)
            Field("Base damage", base, { base = it }, KeyboardType.Decimal)
            Field("Total damage bonus (%)", bonus, { bonus = it }, KeyboardType.Decimal)
            Text("Estimated damage: ${"%.0f".format(baseDamage * (1 + bonusPct / 100))}", color = Gold)
            Text("Illustrative estimate only. Exact rally mechanics and hero bonuses must be added before this can predict game results.", color = Color.LightGray, fontSize = 11.sp)
        } } }
    }
}

@Composable private fun Field(label: String, value: String, onValue: (String)->Unit, type: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = type))
}
