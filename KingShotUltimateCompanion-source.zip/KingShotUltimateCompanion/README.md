# King Shot Ultimate Companion (starter build)

An Android companion app starter for personal King Shot profile tracking and planning.

## Included in this first source build
- Dark purple/gold dashboard
- Local profile fields (player ID, kingdom, power)
- Editable hero roster notes, saved locally
- Basic troop-time estimate calculator
- Basic Bear Trap/damage estimate calculator
- No game-server modification, resource injection, botting, or credential collection

## Important integration status
This project does **not** yet sign into Google or King Shot and does **not** claim live game synchronisation. A Google-linked game account does not give a third-party app permission to read game data. Before implementing OAuth, obtain a registered OAuth client and confirm the game's supported authorisation/API scopes. Never collect a Google password or reuse game session cookies.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. This environment did not have Android SDK/Gradle installed, so an APK could not be compiled here.

## Next integration milestones
1. Confirm a legitimate King Shot account-data API/OAuth flow and permitted scopes.
2. Add secure token storage and read-only sync.
3. Add structured hero/equipment/troop/inventory models and import flow.
4. Implement verified game-mode formulas and recommendations with versioned data sources.
5. Add backup/export and sync status.
